// Estado da aplicação
let conversationHistory = [];
let isLoading = false;
let lovableTabId = null;
let isLovableConnected = false;
let sessionData = null;

// DOM Elements
const messagesContainer = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-btn');
const clearButton = document.getElementById('clear-btn');
const settingsButton = document.getElementById('settings-btn');
const statusIndicator = document.querySelector('.status-indicator');
const statusText = document.getElementById('status-text');

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
    loadChatHistory();
    setupEventListeners();
    detectLovableSession();
    checkLovableConnection();
});

function setupEventListeners() {
    sendButton.addEventListener('click', sendMessage);
    clearButton.addEventListener('click', clearChat);
    settingsButton.addEventListener('click', openAboutModal);
    
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
            e.preventDefault();
            sendMessage();
        }
    });

    messageInput.addEventListener('input', adjustTextareaHeight);
}

function adjustTextareaHeight() {
    messageInput.style.height = 'auto';
    messageInput.style.height = Math.min(messageInput.scrollHeight, 100) + 'px';
}

// Detectar Lovable aberto
function detectLovableSession() {
    chrome.tabs.query({}, (tabs) => {
        for (let tab of tabs) {
            if (tab.url && (tab.url.includes('lovable.dev') || tab.url.includes('lovable.app'))) {
                lovableTabId = tab.id;
                console.log('✓ Aba Lovable detectada:', tab.id);
                extractSessionFromLovable();
                return;
            }
        }
        console.log('✗ Nenhuma aba Lovable encontrada');
        updateStatus('error', '✗ Abra o Lovable em outra aba');
    });
}

// Extrair sessão do Lovable
function extractSessionFromLovable() {
    if (!lovableTabId) return;

    chrome.tabs.sendMessage(lovableTabId, { action: 'getSession' }, (response) => {
        if (chrome.runtime.lastError) {
            console.log('Erro ao comunicar com Lovable:', chrome.runtime.lastError);
            return;
        }
        
        if (response && response.session) {
            sessionData = response.session;
            isLovableConnected = true;
            updateStatus('connected', '✓ Conectado ao Lovable');
            console.log('✓ Sessão extraída com sucesso');
        }
    });
}

// Verificar conexão periodicamente
function checkLovableConnection() {
    setInterval(() => {
        if (!isLovableConnected || !lovableTabId) {
            detectLovableSession();
        }
    }, 5000);
}

async function sendMessage() {
    const message = messageInput.value.trim();
    
    if (!message) return;

    if (!lovableTabId || !isLovableConnected) {
        showError('Abra o Lovable em outra aba para usar a extensão!');
        detectLovableSession();
        return;
    }

    isLoading = true;
    sendButton.disabled = true;

    // Adicionar mensagem do usuário
    addMessage(message, 'user');
    messageInput.value = '';
    messageInput.style.height = 'auto';
    conversationHistory.push({ role: 'user', content: message });

    // Mostrar indicador de carregamento
    const loadingEl = document.createElement('div');
    loadingEl.className = 'message assistant';
    loadingEl.innerHTML = `
        <div class="message-avatar">🤖</div>
        <div class="message-content" style="background: #e8e8e8;">
            <div style="display: flex; gap: 4px;">
                <span>●</span><span>●</span><span>●</span>
            </div>
        </div>
    `;
    messagesContainer.appendChild(loadingEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;

    try {
        const response = await sendToLovableAPI(message);
        
        // Remover indicador de carregamento
        loadingEl.remove();
        
        // Adicionar resposta
        addMessage(response, 'assistant');
        conversationHistory.push({ role: 'assistant', content: response });
        saveChatHistory();
        
        updateStatus('connected', '✓ Conectado');
    } catch (error) {
        loadingEl.remove();
        showError(`Erro: ${error.message}`);
        updateStatus('error', '✗ Erro na conexão');
    } finally {
        isLoading = false;
        sendButton.disabled = false;
        messageInput.focus();
    }
}

// Enviar requisição pela aba do Lovable
function sendToLovableAPI(message) {
    return new Promise((resolve, reject) => {
        if (!lovableTabId) {
            reject(new Error('Aba do Lovable não encontrada'));
            return;
        }

        chrome.tabs.sendMessage(
            lovableTabId,
            {
                action: 'sendMessage',
                message: message,
                conversationHistory: conversationHistory
            },
            (response) => {
                if (chrome.runtime.lastError) {
                    reject(new Error('Falha ao comunicar com Lovable: ' + chrome.runtime.lastError.message));
                    return;
                }
                
                if (response && response.success) {
                    resolve(response.content);
                } else if (response && response.error) {
                    reject(new Error(response.error));
                } else {
                    reject(new Error('Resposta inválida do Lovable'));
                }
            }
        );
    });
}

function addMessage(content, role) {
    const messageEl = document.createElement('div');
    messageEl.className = `message ${role}`;
    
    const avatar = role === 'user' ? '👤' : '🤖';
    const contentEl = document.createElement('div');
    contentEl.className = 'message-content';
    
    contentEl.textContent = content;
    contentEl.style.whiteSpace = 'pre-wrap';
    
    messageEl.innerHTML = `<div class="message-avatar">${avatar}</div>`;
    messageEl.appendChild(contentEl);
    
    messagesContainer.appendChild(messageEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

function clearChat() {
    if (confirm('Tem certeza que deseja limpar o histórico de chat?')) {
        conversationHistory = [];
        messagesContainer.innerHTML = '';
        chrome.storage.local.remove('chatHistory');
        messageInput.value = '';
        messageInput.focus();
        addMessage('Histórico limpo! 🗑️', 'assistant');
    }
}

function openAboutModal() {
    alert('🚀 Lovable Unlimited Chat\n\nEsta extensão usa sua sessão do Lovable já autenticada.\n\nStatus: ' + (isLovableConnected ? '✓ Conectado' : '✗ Desconectado'));
}

function loadChatHistory() {
    chrome.storage.local.get(['chatHistory'], (result) => {
        if (result.chatHistory) {
            conversationHistory = result.chatHistory;
            result.chatHistory.forEach(msg => {
                addMessage(msg.content, msg.role);
            });
        } else {
            addMessage(
                'Olá! 👋 Bem-vindo ao Lovable Unlimited!\n\n✓ Abra o Lovable em outra aba\n✓ Faça login se necessário\n✓ Use esta extensão para conversar SEM gastar créditos!\n\nA sessão será detectada automaticamente.',
                'assistant'
            );
        }
    });
}

function saveChatHistory() {
    chrome.storage.local.set({ 
        chatHistory: conversationHistory,
        timestamp: new Date().toISOString()
    });
}

function updateStatus(state, text) {
    statusIndicator.classList.remove('connected', 'error');
    if (state === 'connected') {
        statusIndicator.classList.add('connected');
    } else if (state === 'error') {
        statusIndicator.classList.add('error');
    }
    statusText.textContent = text;
}

function showError(message) {
    const messageEl = document.createElement('div');
    messageEl.className = 'message assistant';
    messageEl.innerHTML = `
        <div class="message-avatar">⚠️</div>
        <div class="message-content" style="background: #ffebee; color: #c62828; border-color: #ef5350;">
            ${message}
        </div>
    `;
    messagesContainer.appendChild(messageEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}
