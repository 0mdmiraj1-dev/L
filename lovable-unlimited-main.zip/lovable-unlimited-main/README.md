# 🚀 Lovable Unlimited Chat

Uma extensão Chrome que permite conversar com o Lovable **sem usar créditos**, usando sua sessão já autenticada.

## ✨ Características

- 💬 **Chat ilimitado** - Sem limite de créditos
- 🔓 **Sem API Key** - Usa sua sessão autenticada
- 🔗 **Detecção automática** - Encontra Lovable aberto automaticamente
- 📝 **Histórico persistente** - Conversas salvas automaticamente
- ⚡ **Sem configuração** - Basta abrir Lovable em outra aba
- 🛡️ **Seguro** - Usa apenas sua sessão existente

## 📋 Requisitos

- Google Chrome/Chromium (versão 88+)
- Conta Lovable ativa e autenticada
- Lovable aberto em uma aba do Chrome

## ⚙️ Instalação

### 1. Clone o Repositório

```bash
git clone https://github.com/marcolinochicupa01-design/lovable-unlimited.git
cd lovable-unlimited
```

### 2. Carregue a Extensão

1. Abra `chrome://extensions/` no Chrome
2. Ative o **"Modo de desenvolvedor"** (canto superior direito)
3. Clique em **"Carregar extensão não empacotada"**
4. Selecione a pasta `lovable-unlimited`

### 3. Pronto!

A extensão está instalada e pronta para usar.

## 💻 Como Usar

### Primeira Vez:

1. **Abra o Lovable** em uma aba: [lovable.dev](https://lovable.dev)
2. **Faça login** se necessário
3. **Clique no ícone da extensão** no canto superior direito do Chrome
4. **Veja o status** mudar para "✓ Conectado"

### Conversando:

1. **Digite sua mensagem** na caixa de texto
2. **Pressione Ctrl+Enter** (ou clique em ➤)
3. **Aguarde a resposta** - Lovable executará seu comando
4. **Continue conversando ilimitadamente!**

## 🎯 Como Funciona

```
┌─────────────────┐
│ Extensão Chrome │
└────────┬────────┘
         │ Detecta
         ▼
  ┌──────────────────┐
  │ Aba Lovable Aberta│ (já autenticada)
  └────────┬─────────┘
           │ Extrai sessão
           │ (sem API Key!)
           ▼
    ┌────────────────┐
    │ Faz requisição │
    │ Bypass Credits │
    └────────┬───────┘
             │
             ▼
       ┌──────────┐
       │ Resposta │
       │ Exibida  │
       └──────────┘
```

## 🔒 Segurança

- ✅ **Sem token API** - Não precisa guardar credenciais
- ✅ **Sessão existente** - Usa apenas o que você já tem
- ✅ **Dados locais** - Tudo armazenado no seu navegador
- ✅ **Sem servidores externos** - Comunica apenas com Lovable
- ✅ **Código aberto** - Você pode verificar o que faz

## 🔧 Troubleshooting

**"✗ Abra o Lovable em outra aba"**
- Abra [lovable.dev](https://lovable.dev) em uma aba
- Faça login se necessário
- A extensão detectará automaticamente

**"✗ Erro na conexão"**
- Verifique se está conectado à internet
- Tente recarregar a aba do Lovable (F5)
- Feche e abra a extensão novamente

**A extensão não funciona?**
- Certifique-se de que carregou a extensão em `chrome://extensions/`
- Tente desabilitar e habilitar novamente
- Reinicie o Chrome

## 📄 Licença

MIT License - Sinta-se livre para usar, modificar e distribuir

## 🤝 Contribuições

Contribuições são bem-vindas! Abra um issue ou pull request.

---

**Desenvolvido com ❤️ por marcolinochicupa01-design**

**Não há afiliação oficial com Lovable.**
