// Content Script - Injetado nas páginas do Lovable

console.log('🚀 Lovable Unlimited - Content Script Carregado');

// Armazenar informações da sessão
let lovableSession = {
    authenticated: false,
    conversationId: null,
    userId: null,
    sessionToken: null
};

// Extrair informações da sessão
function extractSessionInfo() {
    try {
        // Tentar extrair do localStorage
        const sessionToken = localStorage.getItem('auth_token');
        const userId = localStorage.getItem('user_id');
        const conversationId = sessionStorage.getItem('conversation_id');
        
        if (sessionToken) {
            lovableSession.sessionToken = sessionToken;
            lovableSession.authenticated = true;
        }
        
        if (userId) lovableSession.userId = userId;
        if (conversationId) lovableSession.conversationId = conversationId;
        
        // Extrair do window object se disponível
        if (window.__LOVABLE_SESSION__) {
            Object.assign(lovableSession, window.__LOVABLE_SESSION__);
        }
        
        console.log('✓ Sessão extraída:', lovableSession);
    } catch (error) {
        console.log('Erro ao extrair sessão:', error);
    }
}

// Executar ao carregar a página
extractSessionInfo();

// Monitorar mudanças na sessão
window.addEventListener('storage', () => {
    extractSessionInfo();
});

// Listener para mensagens da extensão
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('📨 Mensagem recebida:', request.action);
    
    if (request.action === 'getSession') {
        // Retornar informações da sessão
        sendResponse({
            session: lovableSession,
            authenticated: lovableSession.authenticated
        });
    }
    
    else if (request.action === 'sendMessage') {
        // Enviar mensagem ao Lovable
        sendMessageToLovable(request.message, request.conversationHistory, sendResponse);
        return true; // Indicar que a resposta será enviada de forma assíncrona
    }
});

// Função para enviar mensagem
async function sendMessageToLovable(message, conversationHistory, sendResponse) {
    try {
        // Buscar o endpoint da API do Lovable
        const apiResponse = await fetch('/api/v1/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${lovableSession.sessionToken}`,
                'X-Bypass-Credits': 'true'
            },
            body: JSON.stringify({
                message: message,
                conversationHistory: conversationHistory.slice(-10), // Últimas 10 mensagens
                bypassCredits: true
            })
        });
        
        if (!apiResponse.ok) {
            throw new Error(`API Error: ${apiResponse.status}`);
        }
        
        const data = await apiResponse.json();
        
        sendResponse({
            success: true,
            content: data.content || data.message || data.response
        });
    } catch (error) {
        console.error('Erro ao enviar mensagem:', error);
        
        // Tentar método alternativo - interceptar requisição
        try {
            const altResponse = await fetch(window.location.origin + '/api/chat', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Skip-Credit-Check': 'true'
                },
                body: JSON.stringify({
                    prompt: message,
                    history: conversationHistory
                })
            });
            
            if (altResponse.ok) {
                const data = await altResponse.json();
                sendResponse({
                    success: true,
                    content: data.result || data.text || data.content
                });
                return;
            }
        } catch (altError) {
            console.error('Método alternativo também falhou:', altError);
        }
        
        sendResponse({
            success: false,
            error: `Erro na API: ${error.message}`
        });
    }
}

// Injeta um script para acessar dados globais
const script = document.createElement('script');
script.textContent = `
    // Expor dados da sessão para o content script
    window.__LOVABLE_SESSION__ = {
        authenticated: !!localStorage.getItem('auth_token'),
        sessionToken: localStorage.getItem('auth_token'),
        userId: localStorage.getItem('user_id')
    };
    console.log('✓ Sessão exposta para Content Script');
`;
document.documentElement.appendChild(script);
script.remove();
