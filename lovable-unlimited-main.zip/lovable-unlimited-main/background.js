// Service Worker para Lovable Unlimited Extension

chrome.runtime.onInstalled.addListener((details) => {
    if (details.reason === 'install') {
        chrome.storage.local.set({
            chatHistory: []
        });
        console.log('✓ Extensão instalada com sucesso');
    }
});

// Monitorar abas
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.url && (tab.url.includes('lovable.dev') || tab.url.includes('lovable.app'))) {
        if (changeInfo.status === 'complete') {
            console.log('✓ Lovable aba atualizada:', tabId);
            // Injetar content script
            chrome.tabs.executeScript(tabId, { file: 'content.js' }).catch(() => {});
        }
    }
});

// Listener para mensagens
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'getChatHistory') {
        chrome.storage.local.get(['chatHistory'], (result) => {
            sendResponse(result.chatHistory || []);
        });
        return true;
    }
});
